import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notificar-cita',
  templateUrl: './notificar-cita.component.html',
  styleUrls: ['./notificar-cita.component.css']
})
export class NotificarCitaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
