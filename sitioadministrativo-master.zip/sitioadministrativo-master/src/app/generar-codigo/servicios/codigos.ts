export class CodigosAspirante {
    id: number;
    cod_validacion: number;
}
