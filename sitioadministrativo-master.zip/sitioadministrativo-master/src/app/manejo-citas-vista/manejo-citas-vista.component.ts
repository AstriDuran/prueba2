import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manejo-citas-vista',
  templateUrl: './manejo-citas-vista.component.html',
  styleUrls: ['./manejo-citas-vista.component.css']
})
export class ManejoCitasVistaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
