export class Aspirante {
    id_aspirante: number;
    nombreuser_aspirante: string;
    nombre_aspirante: string;
    apellido_aspirante: string;
    contrasena_aspirante: string;
    dui: string;
    genero: string;
    fechas_nac: Date;
    t_fijo: string;
    t_movil: string;
    email: string;
    titulo_pre: string;
    institucion: string;
    f_expedicion: Date;
    municipio: string;
    programa: string;
    aceptado: boolean;
    id_user: number;
    id_val: number;
}
