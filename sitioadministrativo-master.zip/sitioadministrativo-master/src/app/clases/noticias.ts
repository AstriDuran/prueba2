export class Noticias {
	id: number;
	emcabezado: string;
	cuerpo: string;
	fecha: string;
	id_usuario: number;
	imagen: string;
}
