import { Permisos } from "./permisos";
import { Deserializable } from "./model/deserializable.model";

export class Roles{
	id: number;
	name: string;
	permisos: Permisos;

	
}
