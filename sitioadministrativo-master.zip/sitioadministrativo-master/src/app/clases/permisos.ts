export class Permisos {
	id: number;
    name: string;
    codename: string;
    content_type: number;
}
