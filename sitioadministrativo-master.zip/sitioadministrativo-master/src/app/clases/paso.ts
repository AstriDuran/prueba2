import { Procedimiento } from "./procedimiento";

export class Paso {
    id: number;
    nombre: string;
    procedimiento: Procedimiento;
    descripcion: string;
}
