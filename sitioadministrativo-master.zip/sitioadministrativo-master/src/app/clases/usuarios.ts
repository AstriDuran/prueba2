export class Usuarios {
    apellido: String;
    id: number;
    nombre: String;
    nombreUsuario: String;
}
