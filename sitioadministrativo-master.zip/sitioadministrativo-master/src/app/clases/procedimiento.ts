export class Procedimiento {
    id: number;
    nombre: string;
    descripcion: string;
}
