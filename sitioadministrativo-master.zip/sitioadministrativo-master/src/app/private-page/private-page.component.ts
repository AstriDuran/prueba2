import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-private-page',
  templateUrl: './private-page.component.html',
  styleUrls: ['./private-page.component.css']
})
export class PrivatePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
