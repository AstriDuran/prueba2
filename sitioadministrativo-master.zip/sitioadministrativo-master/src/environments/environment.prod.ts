
export const environment = {
  production: true,
  apiUrl: 'https://postgrados.herokuapp.com/'
};